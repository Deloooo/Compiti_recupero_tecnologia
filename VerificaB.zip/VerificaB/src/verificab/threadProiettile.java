/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificab;

/**
 *
 * @author Gabriele
 */
public class threadProiettile extends Thread{
      private DatiCondivisi datiCon;
    private int th;
    
    public threadProiettile(DatiCondivisi dati, int th) {
        this.datiCon = dati;
        this.th = th;
    }
}
