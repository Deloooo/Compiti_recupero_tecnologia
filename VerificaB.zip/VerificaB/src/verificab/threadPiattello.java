/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificab;

/**
 *
 * @author Gabriele
 */
public class threadPiattello extends Thread {

    private DatiCondivisi datiCon;
    private int th;

    public threadPiattello(DatiCondivisi dati, int th) {
        this.datiCon = dati;
        this.th = th;
    }

}
