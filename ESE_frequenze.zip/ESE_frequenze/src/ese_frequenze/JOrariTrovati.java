/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ese_frequenze;

/**
 *
 * @author Gabriele
 */
class JOrariTrovati {
    
    private String partenza;
    private String arrivo;
   
    JOrariTrovati(){
        partenza="";
        arrivo="";
    }
    
    
    JOrariTrovati(String partenza,String arrivo){
        this.arrivo=arrivo;
        this.partenza=partenza;
    }
    
    
    
}
